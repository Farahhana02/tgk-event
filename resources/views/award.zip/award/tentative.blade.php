@extends('layouts.app')

@section('title', 'Program Tentative')

@section('content')
<link rel="stylesheet" href="/assets/css/tentative.css">

<!-- ========================= BREADCRUMB ========================= -->
<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">
        
        <div class="breadcrumb-title">PROGRAM TENTATIVE</div>

        <div class="breadcrumb-path">
            <!-- Home -->
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>

            <span>/</span>

            <!-- Kedah Industry Award -->
            <a class="breadcrumb-link">
                KEDAH INDUSTRIAL AWARD
            </a>

            <span>/</span>

            <!-- Current page -->
            <a href="/award/tentative" class="breadcrumb-link">
                PROGRAM TENTATIVE
            </a>
        </div>

    </div>
</div>

<!-- ========================= CONTENT WRAPPER ========================= -->
<div class="content-container">

    <!-- ============================================
         PROGRAM HEADER
    ============================================ -->
    <div class="program-header">
        <h2 class="program-title">Tentative Programme</h2>
        <h3 class="program-subtitle">Kedah State Industrial Awards Night 2026</h3>
    </div>

    <!-- ============================================
         EVENT INFO
    ============================================ -->
    <div class="event-info">
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Date</span>
                <span class="info-value">23 January 2026 (Friday)</span>
            </div>
            <div class="info-item">
                <span class="info-label">Time</span>
                <span class="info-value">7.30 PM - 11.00 PM</span>
            </div>
            <div class="info-item">
                <span class="info-label">Location</span>
                <span class="info-value">Raia Hotel, Alor Setar</span>
            </div>
            <div class="info-item">
                <span class="info-label">Theme</span>
                <span class="info-value">Gold & Black</span>
            </div>
        </div>
    </div>

    <!-- ============================================
         SCHEDULE TABLE
    ============================================ -->
    <div class="schedule-container">
        <div class="schedule-header">
            <h3 class="schedule-main-title">Tentative Programme</h3>
            <p class="schedule-sub-title">Schedule</p>
        </div>
        
        <!-- OPTION 1: Clean Table Design -->
        <table class="schedule-table">
            <thead>
                <tr>
                    <th>TIME</th>
                    <th>PROGRAMME</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="time-cell">7.30 PM</td>
                    <td class="activity-cell">Guest Arrival & Registration</td>
                </tr>
                <tr>
                    <td class="time-cell">8.00 PM</td>
                    <td class="activity-cell">
                        <span class="activity-title">Arrival of Guest of Honour</span>
                        <span class="activity-subtitle">Dato' Seri Haji Muhammad Sanusi Bin Md Nor, Chief Minister of Kedah</span>
                    </td>
                </tr>
                <tr>
                    <td class="time-cell">8.15 PM</td>
                    <td class="activity-cell">National Anthem, State Anthem, Greetings & Opening Prayer</td>
                </tr>
                <tr>
                    <td class="time-cell">8.30 PM</td>
                    <td class="activity-cell">
                        <span class="activity-title">Welcome Speech by</span>
                        <span class="activity-subtitle">Prof. Dr. Haim Hilman Bin Abdullah, Chairman, Kedah Investment, Industrial Development, Higher Education, Technology & Innovation Committee</span>
                    </td>
                </tr>
                <tr>
                    <td class="time-cell">8.45 PM</td>
                    <td class="activity-cell">Video Montage Presentation</td>
                </tr>
                <tr>
                    <td class="time-cell">8.50 PM</td>
                    <td class="activity-cell">
                        <span class="activity-title">Ceremony Speech by Guest of Honour</span>
                        <span class="activity-subtitle">Dato' Seri Haji Muhammad Sanusi Bin Md Nor, Chief Minister of Kedah</span>
                    </td>
                </tr>
                <tr>
                    <td class="time-cell">9.15 PM</td>
                    <td class="activity-cell">Kedah Industry Award Presentation</td>
                </tr>
                <tr>
                    <td class="time-cell">10.00 PM</td>
                    <td class="activity-cell">Appreciation Ceremony for Tunku Mahmud Fund Sponsors</td>
                </tr>
                <tr>
                    <td class="time-cell">10.15 PM</td>
                    <td class="activity-cell">Dinner & Fellowship</td>
                </tr>
                <tr>
                    <td class="time-cell">10.50 PM</td>
                    <td class="activity-cell">Photo Session</td>
                </tr>
                <tr>
                    <td class="time-cell">11.00 PM</td>
                    <td class="activity-cell">End of Ceremony</td>
                </tr>
            </tbody>
        </table>

        <!-- OPTION 2: Timeline Design (Uncomment to use) -->
        <!--
        <div class="event-timeline">
            <div class="timeline-item">
                <div class="timeline-time">7.30 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Guest Arrival & Registration</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">8.00 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Arrival of Guest of Honour</div>
                    <div class="timeline-description">Dato' Seri Haji Muhammad Sanusi Bin Md Nor, Chief Minister of Kedah</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">8.15 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">National Anthem, State Anthem, Greetings & Opening Prayer</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">8.30 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Welcome Speech</div>
                    <div class="timeline-description">Prof. Dr. Haim Hilman Bin Abdullah, Chairman, Kedah Investment, Industrial Development, Higher Education, Technology & Innovation Committee</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">8.45 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Video Montage Presentation</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">8.50 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Ceremony Speech by Guest of Honour</div>
                    <div class="timeline-description">Dato' Seri Haji Muhammad Sanusi Bin Md Nor, Chief Minister of Kedah</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">9.15 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Kedah Industry Award Presentation</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">10.00 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Appreciation Ceremony for Tunku Mahmud Fund Sponsors</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">10.15 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Dinner & Fellowship</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">10.50 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">Photo Session</div>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-time">11.00 PM</div>
                <div class="timeline-content">
                    <div class="timeline-title">End of Ceremony</div>
                </div>
            </div>
        </div>
        -->
    </div>

</div>

@endsection