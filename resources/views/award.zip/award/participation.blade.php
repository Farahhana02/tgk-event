@extends('layouts.app')
@section('title', 'Participation')
@section('content')
<link rel="stylesheet" href="/assets/css/participation.css">

<!-- Breadcrumb -->
<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">
        <div class="breadcrumb-title">PARTICIPATION</div>
        <div class="breadcrumb-path">
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>
            <span>/</span>
            <a href="/award" class="breadcrumb-link">KEDAH INDUSTRIAL AWARD</a>
            <span>/</span>
            <a href="/award/participation" class="breadcrumb-link">PARTICIPATION</a>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="participation-container">
    <!-- Table & Chair Sales Title (VIP Style) -->
    <h2 class="pricing-section-title">TABLE & CHAIR SALES</h2>
    <h3 class="pricing-section-subtitle">KEDAH INDUSTRIAL AWARD 2026</h3>

    <!-- Hero Section -->
    <div class="participation-hero">
        <div class="hero-decorative-top"></div>
        <div class="hero-content">
            <p class="hero-description">
                To provide opportunity for <span class="highlight-text">industry companies to participate in the Kedah Industrial Awards</span>, 
                the Program Secretariat is pleased to offer corporate table and seat packages as follows:
            </p>
        </div>
        <div class="hero-decorative-bottom"></div>
    </div>

    <!-- Pricing Section -->
    <div class="pricing-section">
        <div class="pricing-card">
            <div class="pricing-header table-header">
                <div class="icon-wrapper">
                    <img src="../assets/images/table.png" alt="Table" class="pricing-icon">
                </div>
                <div class="pricing-label">1 TABLE (10 PAX)</div>
            </div>
            <div class="pricing-amount">RM 2,000.00</div>
        </div>

        <div class="pricing-card">
            <div class="pricing-header chair-header">
                <div class="icon-wrapper">
                    <img src="../assets/images/chair.png" alt="Chair" class="pricing-icon">
                </div>
                <div class="pricing-label">1 INDIVIDUAL CHAIR</div>
            </div>
            <div class="pricing-amount">RM 250.00</div>
        </div>
    </div>

    <!-- Event Details -->
    <div class="event-details-section">
        <h3 class="section-title">EVENT DETAILS</h3>
        <div class="details-grid">
            <div class="detail-item">
                <span class="detail-label">Date:</span>
                <span class="detail-value">23 January 2026 (Friday)</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Time:</span>
                <span class="detail-value">7:30 AM - 11:00 AM</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Venue:</span>
                <span class="detail-value">Raia Hotel, Alor Setar</span>
            </div>
        </div>
    </div>

    <!-- Payment Information -->
    <div class="payment-info-section">
        <h3 class="section-title">PAYMENT & SUBMISSION INFORMATION</h3>
        <div class="info-list">
            <div class="info-item">
                <span class="info-number">a)</span>
                <span class="info-text">Participation fee for 1 Table (10 pax) is RM 2,000.00</span>
            </div>
            <div class="info-item">
                <span class="info-number">b)</span>
                <span class="info-text">Participation fee for 1 Individual Chair is RM 250.00</span>
            </div>
            <div class="info-item">
                <span class="info-number">c)</span>
                <span class="info-text">Payment can be made via bank transfer in cash or cash deposit as follows:</span>
            </div>
            
            <div class="bank-details">
                <div class="bank-item">
                    <span class="bank-label">Account No.:</span>
                    <span class="bank-value">02011010080008</span>
                </div>
                <div class="bank-item">
                    <span class="bank-label">Bank Name:</span>
                    <span class="bank-value">Bank Islam Malaysia Berhad</span>
                </div>
                <div class="bank-item">
                    <span class="bank-label">Account Name:</span>
                    <span class="bank-value">Bendahari Negeri Kedah</span>
                </div>
            </div>


            <div class="info-item">
                <span class="info-number">d)</span>
                <span class="info-text">After payment and form submission, you will receive a confirmation email for this program</span>
            </div>
            <div class="info-item">
                <span class="info-number">e)</span>
                <span class="info-text">Any inquiries and further questions can be directed to the Program Secretariat at 012-4678587 (Ms. Mu'ni Invest Kedah) or 017-4101239 (Mr. Iqbal EXCO Officer) or via email at <a href="mailto:anugerahindustri@kedah.gov.my">anugerahindustri@kedah.gov.my</a></span>
            </div>
        </div>
    </div>

    <!-- CTA Button -->
    <div class="cta-section">
        <a href="/award/participation/form" class="btn-join-now">
            <span>JOIN NOW</span>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </a>
    </div>
</div>

@endsection