@extends('layouts.app')

@section('title', 'Award Overview')

@section('content')
<link rel="stylesheet" href="/assets/css/overview.css">

<!-- ========================= BREADCRUMB ========================= -->
<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">

        <div class="breadcrumb-title">OVERVIEW</div>

        <div class="breadcrumb-path">
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>

            <span>/</span>

            <a class="breadcrumb-link">KEDAH INDUSTRIAL AWARD</a>

            <span>/</span>

            <a href="/award/overview" class="breadcrumb-link">OVERVIEW</a>
        </div>

    </div>
</div>

<!-- ========================= HERO SECTION ========================= -->
<section class="hero-section">
    <div class="hero-content">
        <h1 class="hero-title">KEDAH INDUSTRY AWARD</h1>
    </div>
</section>

<!-- ========================= WELCOME SECTION ========================= -->
<section class="welcome-section">
    <h2 class="welcome-title">Welcome</h2>
</section>

<!-- ========================= CONTENT WRAPPER ========================= -->
<div class="content-container">

    <!-- ============================================
         1. INTRODUCTION
    ============================================ -->
    <section class="section-block">
        <h3 class="section-title">Introduction</h3>

        <p class="intro-short">
            The Kedah State Industry Award Night 2026 is a prestigious initiative by the Kedah Darul Aman State Government to recognize the significant contributions of industry players...
        </p>

        <div id="intro-full" class="hidden intro-full">

            <p>
                The Kedah State Industry Award Night 2026 is a prestigious initiative by the Kedah Darul Aman State Government to recognize the significant contributions of industry players, strategic investors, and economic development partners who have collectively driven the state's progress.
            </p>

            <p>
                This event not only aims to honor companies that demonstrate outstanding performance, but also serves as an important platform to strengthen government-industry relations within the framework of The Greater Kedah aspirations.
            </p>

            <p>
                In line with the rapid development of investment, technology, and innovation sectors in Kedah, the state government also gives serious attention to the development of highly skilled human capital to meet future industry needs.
            </p>

            <p>
                Therefore, this document also presents the Tunku Mahmud Fund Sponsorship Offer as an effort to develop state talent development programs, including the Kedah Young Scientist Programme (KYSP) and Kedah Young Professional Programme (KYPP).
            </p>

            <p>
                Through the organization of this event and educational sponsorship initiatives, the Kedah State Government demonstrates its commitment to building a strong, competitive, and inclusive industrial ecosystem for the state's increasingly rapid economic future.
            </p>

            <p>
                This document is prepared as an official reference for sponsors, strategic partners, and all industry parties who wish to contribute together to the future of Kedah's children and the state's increasingly rapid development.
            </p>
        </div>

        <button id="toggleIntro" class="see-more-btn">See More</button>
    </section>


    <!-- ============================================
         2. BACKGROUND
    ============================================ -->
    <section class="section-block">
        <h3 class="section-title">Background of Industrial Development and Investment in Kedah State</h3>

        <p class="latar-short">
            Kedah State has shown very encouraging investment performance, particularly in foreign direct investment (FDI) and domestic investment inflows...
        </p>

        <div id="latar-full" class="hidden latar-full">

            <p>
                In recent years, Kedah State has shown very encouraging investment performance, particularly in foreign direct investment (FDI) and domestic investment (DDI) inflows. Kedah remains among the states recording the highest high-tech investment receipts in Malaysia, driven by strengths in manufacturing, semiconductor, electronics, aerospace industry, automotive component manufacturing, data centers, and rubber-based downstream industries.
            </p>

            <p>
                This consistent FDI momentum also strengthens Kedah's position as a destination of choice for investors seeking a mature industrial ecosystem, stable government support, and a highly skilled workforce.
            </p>

            <p>
                This rapid development is supported by the expansion of strategic industrial areas such as Kulim Hi-Tech Park, Sidam Logistics, Aerospace & Manufacturing Hub, Kedah Rubber City, and Bukit Kayu Hitam Special Economic Zone (SBEZ).
            </p>

            <p>
                Each of these areas plays an important role in forming a more comprehensive industrial value chain, while providing opportunities for global companies to establish high-tech based operations in Kedah.
            </p>

            <p>
                This dynamic industrial growth directly triggers increased demand for support services, including logistics, automation, engineering, transportation, and professional services.
            </p>

        </div>

        <button id="toggleLatar" class="see-more-btn">See More</button>
    </section>


    <!-- ============================================
         3. OBJECTIVES
    ============================================ -->
    <section class="section-block">
        <h3 class="section-title">Objectives</h3>

        <ol class="objective-list">
            <li>
                <strong>Recognize contributions of industry players and strategic investors</strong>
                Honoring companies, investors, and industry partners who demonstrate excellence.
            </li>

            <li>
                <strong>Strengthen government-industry cooperation network</strong>
                Making this event a strategic platform to bring together state government leadership and investors.
            </li>

            <li>
                <strong>Support The Greater Kedah agenda</strong>
                Elevating the narrative of high-tech industrial development and innovation.
            </li>

            <li>
                <strong>Empower Kedah's human capital development</strong>
                Ensuring talent pipeline through KYSP and KYPP.
            </li>

            <li>
                <strong>Strengthen education fund and welfare for Kedah state students</strong>
                Empowering Tunku Mahmud Fund sponsorship for state students.
            </li>
        </ol>
    </section>

</div>


<script src="/assets/js/overview.js"></script>
@endsection