@extends('layouts.app')

@section('title', 'VIP')

@section('content')
<link rel="stylesheet" href="/assets/css/guest.css">

<!-- ========================= BREADCRUMB ========================= -->
<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">
        
        <div class="breadcrumb-title">VIP</div>

        <div class="breadcrumb-path">
            <!-- Home -->
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>

            <span>/</span>

            <!-- Kedah Industry Award -->
            <a class="breadcrumb-link">
                KEDAH INDUSTRIAL AWARD
            </a>

            <span>/</span>

            <!-- Current page -->
            <a href="/award/guest" class="breadcrumb-link">
                VIP
            </a>
        </div>

    </div>
</div>

<!-- ========================= CONTENT WRAPPER ========================= -->
<div class="content-container">

    <!-- ============================================
         VIP HEADER
    ============================================ -->
    <div class="vip-header">
        <h2 class="vip-title">VIP</h2>
        <h3 class="vip-subtitle">Kedah Industrial Award 2026</h3>
    </div>

    <!-- ============================================
         VIP LIST WITH IMAGE PLACEHOLDERS
    ============================================ -->
    <div class="vip-list-container">
        
        <!-- VIP 1 -->
        <div class="vip-item">
            <div class="vip-image-column">
                <div class="image-placeholder">
                    <div class="image-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </div>
                </div>
            </div>
            <div class="vip-details-column">
                <div class="vip-name">
                    <div class="name-line">YAB Dato' Seri Haji Muhammad Sanusi Bin Md Nor</div>
                </div>
                <div class="vip-position">Menteri Besar Negeri Kedah</div>
            </div>
        </div>

        <!-- VIP 2 -->
        <div class="vip-item">
            <div class="vip-image-column">
                <div class="image-placeholder">
                    <div class="image-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </div>
                </div>
            </div>
            <div class="vip-details-column">
                <div class="vip-name">
                    <div class="name-line">YB Dato' Seri Haji Narizan Bin Khazali</div>
                </div>
                <div class="vip-position">Setiausaha Kerajaan Negeri Kedah</div>
            </div>
        </div>

        <!-- VIP 3 -->
        <div class="vip-item">
            <div class="vip-image-column">
                <div class="image-placeholder">
                    <div class="image-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </div>
                </div>
            </div>
            <div class="vip-details-column">
                <div class="vip-name">
                    <div class="name-line">YB Dr. Haim Hilman Bin Abdullah</div>
                </div>
                <div class="vip-position">Pengerusi Jawatankuasa Industri & Pelaburan, Pengajian Tinggi dan Sains, Teknologi & Inovasi Negeri Kedah</div>
            </div>
        </div>

        <!-- VIP 4 -->
        <div class="vip-item">
            <div class="vip-image-column">
                <div class="image-placeholder">
                    <div class="image-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </div>
                </div>
            </div>
            <div class="vip-details-column">
                <div class="vip-name">
                    <div class="name-line">Dato' Wira Haji Syed Khairol Anuar Bin Syed Abidin</div>
                </div>
                <div class="vip-position">Pegawai Kewangan Negeri Kedah</div>
            </div>
        </div>

    </div>

    <!-- ============================================
         ACCOMPANIED SECTION
    ============================================ -->
    <div class="accompanied-section">
        <div class="accompanied-text">
            Together with the Members of the Kedah State Executive Council, the Senior Leadership of the Kedah State Government, MIDA Kedah, Invest Kedah, FMM, and KITA.
        </div>
    </div>

</div>

@endsection