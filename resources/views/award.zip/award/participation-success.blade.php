@extends('layouts.app')
@section('title', 'Registration Successful')
@section('content')
<link rel="stylesheet" href="/assets/css/participation.css">

<!-- Breadcrumb -->
<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">
        <div class="breadcrumb-title">REGISTRATION SUCCESSFUL</div>
        <div class="breadcrumb-path">
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>
            <span>/</span>
            <a href="/award" class="breadcrumb-link">KEDAH INDUSTRIAL AWARD</a>
            <span>/</span>
            <a href="/award/participation" class="breadcrumb-link">PARTICIPATION</a>
            <span>/</span>
            <span class="breadcrumb-current">SUCCESS</span>
        </div>
    </div>
</div>

<!-- Success Container -->
<div class="participation-container">
    <div class="success-wrapper">
        <!-- Success Icon -->
        <div class="success-icon">
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
                <circle cx="40" cy="40" r="40" fill="#28a745" opacity="0.1"/>
                <path d="M25 40L35 50L55 30" stroke="#28a745" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>

        <!-- Success Message -->
        <h1 class="success-title">Registration Submitted Successfully!</h1>
        <p class="success-description">
            Thank you for registering for the Kedah Industrial Council Award 2026. 
            Your registration has been received and is currently pending confirmation.
        </p>

        <!-- Registration Details -->
        <div class="details-card">
            <h3 class="details-title">Registration Details</h3>
            
            <div class="detail-row">
                <span class="detail-label">Company Name:</span>
                <span class="detail-value">{{ $participation->company_name }}</span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Employee Name:</span>
                <span class="detail-value">{{ $participation->employee_name }}</span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Phone Number:</span>
                <span class="detail-value">{{ $participation->phone_number }}</span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Participation Type:</span>
                <span class="detail-value">{{ $participation->participation_type_label }}</span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Quantity:</span>
                <span class="detail-value">{{ $participation->quantity }}</span>
            </div>

            <div class="detail-row highlight">
                <span class="detail-label">Total Amount:</span>
                <span class="detail-value">{{ $participation->formatted_total_amount }}</span>
            </div>

            @if($participation->participation_type === 'table' && $participation->attendees)
            <div class="attendees-section">
                <h4 class="attendees-title">Attendees</h4>
                <div class="attendees-list">
                    @foreach($participation->attendees as $index => $attendee)
                        @if(!empty($attendee['name']) || !empty($attendee['position']))
                        <div class="attendee-item">
                            <span class="attendee-number">{{ $index + 1 }}.</span>
                            <div class="attendee-info">
                                <div class="attendee-name">{{ $attendee['name'] ?? 'N/A' }}</div>
                                <div class="attendee-position">{{ $attendee['position'] ?? 'N/A' }}</div>
                            </div>
                        </div>
                        @endif
                    @endforeach
                </div>
            </div>
            @endif
        </div>

        <!-- Payment Instructions -->
        <div class="payment-reminder">
            <h3 class="reminder-title">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM13 17H11V15H13V17ZM13 13H11V7H13V13Z" fill="#DAA520"/>
                </svg>
                Next Steps - Payment Required
            </h3>
            <div class="reminder-content">
                <p>Please proceed with payment via bank transfer:</p>
                <div class="bank-info">
                    <div class="bank-detail">
                        <strong>Account No.:</strong> 02011010080008
                    </div>
                    <div class="bank-detail">
                        <strong>Bank Name:</strong> Bank Islam Malaysia Berhad
                    </div>
                    <div class="bank-detail">
                        <strong>Account Name:</strong> Bendahari Negeri Kedah
                    </div>
                    <div class="bank-detail">
                        <strong>Amount:</strong> {{ $participation->formatted_total_amount }}
                    </div>
                </div>
                <p class="reminder-note">
                    After making payment, please send your payment receipt to 
                    <a href="mailto:anugerahindustri@kedah.gov.my">anugerahindustri@kedah.gov.my</a>
                </p>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="success-actions">
            <a href="/award/participation" class="btn-secondary">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M15 10H5M5 10L10 15M5 10L10 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Back to Participation
            </a>
            <a href="/" class="btn-primary">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M3 10L10 3L17 10M5 8V17H8V13H12V17H15V8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Go to Home
            </a>
        </div>
    </div>
</div>

@endsection