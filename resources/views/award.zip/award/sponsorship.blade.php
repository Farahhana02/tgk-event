@extends('layouts.app')

@section('title', 'Sponsorship Package')

@section('content')
<link rel="stylesheet" href="/assets/css/sponsorship.css">

<!-- ========================= BREADCRUMB ========================= -->
<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">
        
        <div class="breadcrumb-title">SPONSORSHIP PACKAGE</div>

        <div class="breadcrumb-path">
            <!-- Home -->
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>

            <span>/</span>

            <!-- Kedah Industry Award -->
            <a class="breadcrumb-link">
                KEDAH INDUSTRIAL AWARD
            </a>

            <span>/</span>

            <!-- Current page -->
            <a href="/award/sponsorship" class="breadcrumb-link">
                SPONSORSHIP PACKAGE
            </a>
        </div>

    </div>
</div>

<!-- ========================= CONTENT WRAPPER ========================= -->
<div class="content-container">

    <!-- ============================================
         SECTION 1: MODERN PRICING CARDS (IMAGE 2)
    ============================================ -->
    <div class="sponsorship-section">
        <h2 class="section-title">Event Sponsorship Packages</h2>
        <div class="section-divider"></div>
        
        <div class="pricing-grid">
            <!-- Platinum -->
            <div class="pricing-card featured">
                <div class="pricing-header">
                    <div class="pricing-tier">Platinum Sponsor</div>
                    <h3 class="pricing-amount">RM 200,000</h3>
                </div>
                <div class="pricing-body">
                    <p class="pricing-description">Premium package with maximum benefits and highest visibility</p>
                </div>
            </div>
            
            <!-- Gold -->
            <div class="pricing-card">
                <div class="pricing-header">
                    <div class="pricing-tier">Gold Sponsor</div>
                    <h3 class="pricing-amount">RM 100,000</h3>
                </div>
                <div class="pricing-body">
                    <p class="pricing-description">High-quality package with extensive media coverage</p>
                </div>
            </div>
            
            <!-- Silver -->
            <div class="pricing-card">
                <div class="pricing-header">
                    <div class="pricing-tier">Silver Sponsor</div>
                    <h3 class="pricing-amount">RM 50,000</h3>
                </div>
                <div class="pricing-body">
                    <p class="pricing-description">Standard package with effective promotion</p>
                </div>
            </div>
            
            <!-- Bronze -->
            <div class="pricing-card">
                <div class="pricing-header">
                    <div class="pricing-tier">Bronze Sponsor</div>
                    <h3 class="pricing-amount">RM 30,000</h3>
                </div>
                <div class="pricing-body">
                    <p class="pricing-description">Basic package with essential promotional benefits</p>
                </div>
            </div>
            
            <!-- Budi -->
            <div class="pricing-card">
                <div class="pricing-header">
                    <div class="pricing-tier">Budi Sponsor</div>
                    <h3 class="pricing-amount">RM 10,000</h3>
                </div>
                <div class="pricing-body">
                    <p class="pricing-description">Support package with corporate recognition</p>
                </div>
            </div>
        </div>
        
        <div class="disclaimer-box">
            <p class="disclaimer-text">
                Each cash sponsorship will receive 
                <span class="highlight">official receipt</span> from the Kedah State Government
                and is eligible for <span class="highlight">tax exemption</span>
            </p>
        </div>
    </div>

    <!-- ============================================
         SECTION 2: MODERN BENEFITS TABLE (IMAGE 3)
    ============================================ -->
    <div class="sponsorship-section">
        <h2 class="section-title">Sponsorship Benefits Comparison</h2>
        <div class="section-divider"></div>
        
        <div class="benefits-table-wrapper">
            <table class="benefits-table">
                <thead>
                    <tr>
                        <th>Benefits</th>
                        <th>Platinum</th>
                        <th>Gold</th>
                        <th>Silver</th>
                        <th>Bronze</th>
                        <th>Budi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Row 1 -->
                    <tr>
                        <td>Main logo on stage backdrop and all promotional materials</td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td></td>
                    </tr>
                    
                    <!-- Row 2 -->
                    <tr>
                        <td>Promotional booth at event venue</td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    
                    <!-- Row 3 -->
                    <tr>
                        <td>Company name mentioned by event emcee</td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td></td>
                    </tr>
                    
                    <!-- Row 4 -->
                    <tr>
                        <td>Publicity on social media & press releases and official Invest Kedah magazine</td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td class="note-cell">(program book)</td>
                    </tr>
                    
                    <!-- Row 5 -->
                    <tr>
                        <td>Mock cheque presentation and trophy by MB</td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    
                    <!-- Row 6 -->
                    <tr>
                        <td>Display on LED Screen/Stage – (1-minute company sponsorship video)</td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td></td>
                        <td></td>
                    </tr>
                    
                    <!-- Row 7 -->
                    <tr>
                        <td>10 Invitations - 2 at VIP table (Adjacent to main table) and 8 at VP table</td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                        <td><span class="check-icon">✓</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="footer-note">
            *Each sponsorship is eligible for tax exemption
        </div>
    </div>

</div>

@endsection