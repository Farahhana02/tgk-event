@extends('layouts.app')
@section('title', 'Participation Form')
@section('content')
<link rel="stylesheet" href="/assets/css/participation.css">

<!-- Breadcrumb -->
<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">
        <div class="breadcrumb-title">PARTICIPATION FORM</div>
        <div class="breadcrumb-path">
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>
            <span>/</span>
            <a href="/award" class="breadcrumb-link">KEDAH INDUSTRIAL AWARD</a>
            <span>/</span>
            <a href="/award/participation" class="breadcrumb-link">PARTICIPATION</a>
            <span>/</span>
            <span class="breadcrumb-current">FORM</span>
        </div>
    </div>
</div>

<!-- Form Container -->
<div class="participation-container">
    <div class="form-wrapper">
        <!-- Form Header -->
        <div class="form-header">
            <div class="form-logo">
                <img src="/assets/images/crest.png" alt="Kedah Logo" class="header-logo">
            </div>
            <h1 class="form-main-title">PARTICIPATION FORM</h1>
            <h2 class="form-sub-title">KEDAH INDUSTRIAL AWARD 2026</h2>
            <div class="form-event-info">
                <p><strong>Date:</strong> 23 January 2026 (Friday)</p>
                <p><strong>Time:</strong> 7:30 AM - 11:00 AM</p>
                <p><strong>Venue:</strong> Raia Hotel, Alor Setar</p>
            </div>
        </div>

        <!-- Success Message -->
        @if(session('success'))
        <div class="alert alert-success">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM8 15L3 10L4.41 8.59L8 12.17L15.59 4.58L17 6L8 15Z" fill="currentColor"/>
            </svg>
            {{ session('success') }}
        </div>
        @endif

        <!-- Error Messages -->
        @if($errors->any())
        <div class="alert alert-error">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M10 0C4.48 0 0 4.48 0 10C0 15.52 4.48 20 10 20C15.52 20 20 15.52 20 10C20 4.48 15.52 0 10 0ZM11 15H9V13H11V15ZM11 11H9V5H11V11Z" fill="currentColor"/>
            </svg>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        <!-- Form -->
        <form action="{{ route('participation.store') }}" method="POST" class="participation-form" id="participationForm">
            @csrf

            <!-- Company Information Section -->
            <div class="form-section">
                <h3 class="form-section-title">Company Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="company_name" class="form-label">Company Name <span class="required">*</span></label>
                        <input type="text" id="company_name" name="company_name" class="form-control" required value="{{ old('company_name') }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="employee_name" class="form-label">Employee Name <span class="required">*</span></label>
                        <input type="text" id="employee_name" name="employee_name" class="form-control" required value="{{ old('employee_name') }}">
                    </div>

                    <div class="form-group">
                        <label for="phone_number" class="form-label">Phone Number <span class="required">*</span></label>
                        <input type="tel" id="phone_number" name="phone_number" class="form-control" required pattern="[0-9]{10,11}" placeholder="0123456789" value="{{ old('phone_number') }}">
                    </div>
                </div>
            </div>

            <!-- Participation Type Section -->
            <div class="form-section">
                <h3 class="form-section-title">Type of Participation</h3>
                
                <div class="participation-type-grid">
                    <div class="participation-option">
                        <input type="radio" id="type_table" name="participation_type" value="table" class="radio-input" required {{ old('participation_type') == 'table' ? 'checked' : '' }}>
                        <label for="type_table" class="participation-label">
                            <div class="option-content">
                                <div class="option-title">1 Table (10 pax)</div>
                                <div class="option-price">RM 2,000.00</div>
                            </div>
                        </label>
                    </div>

                    <div class="participation-option">
                        <input type="radio" id="type_chair" name="participation_type" value="chair" class="radio-input" required {{ old('participation_type') == 'chair' ? 'checked' : '' }}>
                        <label for="type_chair" class="participation-label">
                            <div class="option-content">
                                <div class="option-title">1 Individual Chair</div>
                                <div class="option-price">RM 250.00</div>
                            </div>
                        </label>
                    </div>
                </div>

                <!-- Quantity field - only shown for Individual Chair -->
                <div class="form-row" id="quantityRow">
                    <div class="form-group">
                        <label for="quantity" class="form-label">Quantity <span class="required">*</span></label>
                        <input type="number" id="quantity" name="quantity" class="form-control" min="1" required value="{{ old('quantity', 1) }}">
                    </div>
                </div>
            </div>

            <!-- Attendees Section (shown for table or multiple chairs) -->
            <div class="form-section" id="attendeesSection" style="display: none;">
                <h3 class="form-section-title">Attendee Details</h3>
                <p class="section-description" id="attendeeDescription">Please provide the names and positions of attendees</p>
                <p class="section-description" id="attendeeNote" style="color: #666; font-size: 0.9em; margin-top: 5px; display: none;">
                    Maximum 10 attendees per table. Each table costs RM 2,000.
                </p>
                
                <!-- Table Cost Summary -->
                <div id="tableCostSummary" style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #e5e7eb; display: none;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div>
                            <strong>Attendees:</strong> <span id="attendeeCount">1</span> / 10 per table
                        </div>
                        <div>
                            <strong>Tables Required:</strong> <span id="tablesRequired">1</span>
                        </div>
                        <div>
                            <strong>Total Cost:</strong> <span id="totalCost" style="color: #2563eb; font-size: 1.2em; font-weight: bold;">RM 2,000</span>
                        </div>
                    </div>
                </div>
                
                <!-- Chair Cost Summary -->
                <div id="chairCostSummary" style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #e5e7eb; display: none;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div>
                            <strong>Attendees:</strong> <span id="chairAttendeeCount">1</span>
                        </div>
                        <div>
                            <strong>Total Cost:</strong> <span id="chairTotalCost" style="color: #2563eb; font-size: 1.2em; font-weight: bold;">RM 250</span>
                        </div>
                    </div>
                </div>
                
                <div id="attendeesList">
                    <div class="attendee-row" data-index="0">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Name</label>
                                <input type="text" name="attendees[0][name]" class="form-control attendee-name" value="{{ old('attendees.0.name') }}">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Position</label>
                                <input type="text" name="attendees[0][position]" class="form-control attendee-position" value="{{ old('attendees.0.position') }}">
                            </div>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn-add-attendee" id="addAttendee">+ Add Another Attendee</button>
                
                <!-- Hidden inputs to store table information -->
                <input type="hidden" name="total_table_cost" id="totalTableCost" value="2000">
                <input type="hidden" name="tables_count" id="tablesCount" value="1">
            </div>

            <!-- Terms & Conditions -->
            <div class="form-section">
                <div class="form-checkbox-group">
                    <input type="checkbox" id="terms" name="terms" class="checkbox-input" required {{ old('terms') ? 'checked' : '' }}>
                    <label for="terms" class="checkbox-label">
                        I agree that the information provided is accurate and I have read the payment instructions
                    </label>
                </div>
            </div>

            <!-- Submit Buttons -->
            <div class="form-actions">
                <a href="/award/participation" class="btn-secondary">Cancel</a>
                <button type="submit" class="btn-primary">
                    <span>Submit Registration</span>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const MAX_ATTENDEES_PER_TABLE = 10;
    const COST_PER_TABLE = 2000;
    const COST_PER_CHAIR = 250;
    
    const tableRadio = document.getElementById('type_table');
    const chairRadio = document.getElementById('type_chair');
    const attendeesSection = document.getElementById('attendeesSection');
    const quantityRow = document.getElementById('quantityRow');
    const quantityInput = document.getElementById('quantity');
    const addAttendeeBtn = document.getElementById('addAttendee');
    const attendeesList = document.getElementById('attendeesList');
    const attendeeDescription = document.getElementById('attendeeDescription');
    const attendeeNote = document.getElementById('attendeeNote');
    const tableCostSummary = document.getElementById('tableCostSummary');
    const chairCostSummary = document.getElementById('chairCostSummary');
    
    let attendeeIndex = 1;
    let currentParticipationType = 'table';

    // Show/hide sections based on participation type
    function toggleSections() {
        if (tableRadio.checked) {
            currentParticipationType = 'table';
            attendeesSection.style.display = 'block';
            quantityRow.style.display = 'none';
            quantityInput.value = 1;
            attendeeDescription.textContent = 'Please provide the names and positions of attendees (for table booking)';
            attendeeNote.style.display = 'block';
            tableCostSummary.style.display = 'flex';
            chairCostSummary.style.display = 'none';
            addAttendeeBtn.style.display = 'block';
            updateTableCost();
        } else {
            currentParticipationType = 'chair';
            quantityRow.style.display = 'block';
            quantityInput.value = 1;
            attendeeDescription.textContent = 'Please provide the names and positions of attendees';
            attendeeNote.style.display = 'none';
            tableCostSummary.style.display = 'none';
            updateChairAttendees();
        }
    }

    // Update table cost calculation
    function updateTableCost() {
        const attendeeCount = document.querySelectorAll('.attendee-row').length;
        const tablesRequired = Math.ceil(attendeeCount / MAX_ATTENDEES_PER_TABLE);
        const totalCost = tablesRequired * COST_PER_TABLE;
        
        document.getElementById('attendeeCount').textContent = attendeeCount;
        document.getElementById('tablesRequired').textContent = tablesRequired;
        document.getElementById('totalCost').textContent = `RM ${totalCost.toLocaleString()}`;
        
        document.getElementById('totalTableCost').value = totalCost;
        document.getElementById('tablesCount').value = tablesRequired;
        quantityInput.value = tablesRequired;
        
        const currentTableAttendees = attendeeCount % MAX_ATTENDEES_PER_TABLE || MAX_ATTENDEES_PER_TABLE;
        const remainingSlots = MAX_ATTENDEES_PER_TABLE - currentTableAttendees;
        
        if (remainingSlots === 0) {
            addAttendeeBtn.textContent = `+ Add Another Attendee (New Table: +RM ${COST_PER_TABLE.toLocaleString()})`;
        } else {
            addAttendeeBtn.textContent = `+ Add Another Attendee (${remainingSlots} slots remaining in current table)`;
        }
    }

    // Update chair attendees based on quantity
    function updateChairAttendees() {
        const chairQuantity = parseInt(quantityInput.value) || 1;
        const currentAttendeeCount = document.querySelectorAll('.attendee-row').length;
        
        // Show attendees section if quantity > 1
        if (chairQuantity > 1) {
            attendeesSection.style.display = 'block';
            chairCostSummary.style.display = 'flex';
            addAttendeeBtn.style.display = 'none'; // Hide add button for chairs
            
            // Update cost summary
            const totalCost = chairQuantity * COST_PER_CHAIR;
            document.getElementById('chairAttendeeCount').textContent = chairQuantity;
            document.getElementById('chairTotalCost').textContent = `RM ${totalCost.toLocaleString()}`;
            
            // Add or remove attendee rows to match quantity
            if (chairQuantity > currentAttendeeCount) {
                // Add more rows
                for (let i = currentAttendeeCount; i < chairQuantity; i++) {
                    addAttendeeRow(i);
                }
            } else if (chairQuantity < currentAttendeeCount) {
                // Remove excess rows
                const rows = document.querySelectorAll('.attendee-row');
                for (let i = chairQuantity; i < currentAttendeeCount; i++) {
                    rows[i]?.remove();
                }
            }
        } else {
            attendeesSection.style.display = 'none';
            // Keep only first attendee row
            const rows = document.querySelectorAll('.attendee-row');
            rows.forEach((row, index) => {
                if (index > 0) row.remove();
            });
        }
    }

    // Add attendee row helper function
    function addAttendeeRow(index) {
        const newRow = document.createElement('div');
        newRow.className = 'attendee-row';
        newRow.setAttribute('data-index', index);
        
        // For chairs, don't show remove button
        const removeButtonHtml = currentParticipationType === 'table' ? 
            '<button type="button" class="btn-remove-attendee" onclick="removeAttendee(this)">Remove</button>' : '';
        
        newRow.innerHTML = `
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Name ${currentParticipationType === 'chair' ? `(Attendee ${index + 1})` : ''}</label>
                    <input type="text" name="attendees[${index}][name]" class="form-control attendee-name">
                </div>
                <div class="form-group">
                    <label class="form-label">Position</label>
                    <input type="text" name="attendees[${index}][position]" class="form-control attendee-position">
                </div>
                ${removeButtonHtml}
            </div>
        `;
        
        attendeesList.appendChild(newRow);
    }

    // Event listeners for participation type
    tableRadio.addEventListener('change', toggleSections);
    chairRadio.addEventListener('change', toggleSections);

    // Event listener for quantity change (for chairs)
    quantityInput.addEventListener('input', function() {
        if (currentParticipationType === 'chair') {
            updateChairAttendees();
        }
    });

    // Check on page load
    toggleSections();

    // Add new attendee row (for tables only)
    addAttendeeBtn.addEventListener('click', function() {
        if (currentParticipationType === 'table') {
            const currentCount = document.querySelectorAll('.attendee-row').length;
            addAttendeeRow(currentCount);
            attendeeIndex = currentCount + 1;
            updateTableCost();
        }
    });

    // Remove attendee function (global scope for onclick)
    window.removeAttendee = function(button) {
        const attendeeCount = document.querySelectorAll('.attendee-row').length;
        if (attendeeCount > 1) {
            button.closest('.attendee-row').remove();
            updateTableCost();
        } else {
            alert('You must have at least one attendee for table booking.');
        }
    };

    // Initial update
    if (currentParticipationType === 'table') {
        updateTableCost();
    } else {
        updateChairAttendees();
    }
});
</script>

@endsection