@extends('layouts.app')

@section('title', 'Program')

@section('content')
<link rel="stylesheet" href="/assets/css/program-public.css">

<div class="breadcrumb-wrapper">
    <div class="breadcrumb-inner">
        
        <div class="breadcrumb-title">PROGRAM</div>

        <div class="breadcrumb-path">
            <!-- Home -->
            <a href="/">
                <img src="/assets/icons/Home.png" class="breadcrumb-home-icon">
            </a>

            <span>/</span>

            <!-- Kedah Industry Award -->
            <a class="breadcrumb-link">
                KEDAH INDUSTRIAL AWARD
            </a>

            <span>/</span>

            <!-- Current page -->
            <a href="/award/program" class="breadcrumb-link">
                PROGRAM
            </a>
        </div>

    </div>
</div>

<!-- PROGRAM CONTENT -->
<div class="program-container">

    <!-- PROGRAM 1: HUMAN & WELFARE CAPITAL DEVELOPMENT PROGRAM 2025 -->
    <section class="program-section">
        <div class="program-header">
            <h2 class="program-title">HUMAN & WELFARE CAPITAL DEVELOPMENT PROGRAM FOR 2025</h2>
        </div>
        
        <div class="program-content">
            <!-- Images Grid -->
            <div class="program-images-grid">
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 1">
                </div>
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 2">
                </div>
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 3">
                </div>
            </div>

            <!-- Description -->
            <div class="program-description">
                <p><strong class="text-highlight">Kedah State Student Assistance Program</strong> is a large-scale joint initiative of the Kedah State Government that brings together various parties to execute projects and activities that take place throughout Kedah State. This program aims to inspire a sense of leadership, while enhancing solidarity and promoting community development for Kedah State.</p>
            </div>

            <!-- More Images -->
            <div class="program-images-grid">
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 4">
                </div>
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 5">
                </div>
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 6">
                </div>
            </div>

            <!-- Description -->
            <div class="program-description">
                <p><strong class="text-highlight">Student Leadership Listening</strong> is a strategic platform that brings together student leaders from all higher education institutions across the state to strengthen leadership competencies, strategic thinking and self-development capacity, along with the agenda of community development in the state.</p>
            </div>

            <!-- More Images -->
            <div class="program-images-grid">
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 7">
                </div>
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 8">
                </div>
                <div class="program-image-box">
                    <img src="../assets/images/placeholder.png" alt="Program Image 9">
                </div>
            </div>

            <!-- Description -->
            <div class="program-description">
                <p><strong class="text-highlight">Savings Support Program for Students</strong> is an initiative to educate the Kedah State Government in providing financial support for students who need college financial assistance. This program ensures that more Kedah children gain access to quality education and are able to achieve academic excellence.</p>
            </div>
        </div>
    </section>

    <!-- PROGRAM 2: KEDAH YOUNG SCIENTIST PROGRAM (KYSP) -->
    <section class="program-section">
        <div class="program-header-yellow">
            <h2 class="program-title-yellow">KEDAH YOUNG SCIENTIST PROGRAM (KYSP)</h2>
        </div>
        
        <div class="program-content-white">
            <div class="two-column-layout">
                <!-- Left Column -->
                <div class="left-column">
                    <div class="image-placeholder-large">
                        <img src="../assets/images/placeholder.png" alt="Young Scientist Icon">
                    </div>
                    <p class="program-subtitle">State program to train young scientists aged 10-17 years old through initial STEM exposure</p>
                </div>

                <!-- Right Column -->
                <div class="right-column">
                    <h3 class="section-subtitle">Program Importance:</h3>
                    <ul class="simple-list">
                        <li>Kedah is developing as a high-tech state</li>
                        <li>Malaysia faces STEM talent shortage</li>
                        <li>80% of future jobs will require mastery of science & technology</li>
                        <li>International students are not sufficiently exposed to STEM approaches</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Main Program Components -->
        <div class="program-header-green">
            <h3 class="section-header-title">MAIN PROGRAM COMPONENTS</h3>
        </div>

        <div class="four-grid-layout">
            <!-- Component 1 -->
            <div class="grid-card yellow-card">
                <h4 class="card-title">STEM Discovery Labs</h4>
                <div class="card-image">
                    <img src="/api/placeholder/200/200" alt="STEM Labs">
                </div>
                <p class="card-text">Hands-on activities: robotics, automation, AI applications, drones, aeronautics, rocket engineering and more</p>
            </div>

            <!-- Component 2 -->
            <div class="grid-card white-card">
                <h4 class="card-title">Young Scientist Mentorship</h4>
                <div class="card-image">
                    <img src="/api/placeholder/200/200" alt="Mentorship">
                </div>
                <p class="card-text">Guidance by university experts, industry practitioners, researchers and Kedah STEM alumni</p>
            </div>

            <!-- Component 3 -->
            <div class="grid-card white-card">
                <h4 class="card-title">Invention Challenge</h4>
                <div class="card-image">
                    <img src="/api/placeholder/200/200" alt="Innovation">
                </div>
                <p class="card-text">Students produce prototypes/experiments/innovative solutions for actual problems</p>
            </div>

            <!-- Component 4 -->
            <div class="grid-card yellow-card">
                <h4 class="card-title">STEM Career Exploration</h4>
                <div class="card-image">
                    <img src="/api/placeholder/200/200" alt="Career">
                </div>
                <p class="card-text">Sessions with professionals such as engineers, E&E experts, aeronautics, data scientists, AI researchers, investigators & product researchers</p>
            </div>
        </div>
    </section>

    <!-- PROGRAM 3: KEDAH YOUNG PROFESSIONAL PROGRAM -->
    <section class="program-section">
        <div class="program-header-yellow">
            <h2 class="program-title-yellow">KEDAH YOUNG PROFESSIONAL PROGRAM</h2>
        </div>
        
        <div class="program-content-white">
            <div class="two-column-layout">
                <!-- Left Column -->
                <div class="left-column">
                    <h3 class="section-subtitle">State initiative for 1,000 Level 3 students across Kedah</h3>
                    <div class="image-placeholder-medium">
                        <img src="/api/placeholder/150/150" alt="Kedah Logo">
                    </div>
                    <p class="info-text">Aligning industry & training development in Kedah with local talent development.</p>
                </div>

                <!-- Right Column -->
                <div class="right-column">
                    <h3 class="section-subtitle">Main Objectives:</h3>
                    <ul class="simple-list">
                        <li>Help determine educational goals</li>
                        <li>Improve academic achievement</li>
                        <li>Build self-identity</li>
                        <li>Train Kedah's professional workforce towards 2030</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Program Importance -->
        <div class="program-header-green">
            <h3 class="section-header-title">PROGRAM IMPORTANCE</h3>
        </div>

        <div class="three-grid-layout">
            <div class="grid-card yellow-card">
                <div class="card-image-small">
                    <img src="/api/placeholder/150/150" alt="Industry">
                </div>
                <p class="card-text-center">High Industry Demand</p>
            </div>

            <div class="grid-card white-card">
                <div class="card-image-small">
                    <img src="/api/placeholder/150/150" alt="Education">
                </div>
                <p class="card-text-center">Overseas Higher Education</p>
            </div>

            <div class="grid-card yellow-card">
                <div class="card-image-small">
                    <img src="/api/placeholder/150/150" alt="Workforce">
                </div>
                <p class="card-text-center">State Future Workforce</p>
            </div>
        </div>

        <!-- Main Program Components -->
        <div class="program-header-green">
            <h3 class="section-header-title">MAIN PROGRAM COMPONENTS</h3>
        </div>

        <div class="three-grid-layout">
            <!-- Component 1 -->
            <div class="grid-card white-card">
                <h4 class="card-title">Intensive Academic</h4>
                <div class="card-image-small">
                    <img src="/api/placeholder/150/150" alt="Academic">
                </div>
                <p class="card-text">Focused subject guidance: Mathematics, Science, BM, BI and History by expert teachers</p>
            </div>

            <!-- Component 2 -->
            <div class="grid-card yellow-card">
                <h4 class="card-title">Self-Development & Goal Setting</h4>
                <div class="card-image-small">
                    <img src="/api/placeholder/150/150" alt="Goals">
                </div>
                <p class="card-text">Activities include career profiling, motivation, time management, study goals and career pathways</p>
            </div>

            <!-- Component 3 -->
            <div class="grid-card white-card">
                <h4 class="card-title">Professional Exposure</h4>
                <div class="card-image-small">
                    <img src="/api/placeholder/150/150" alt="Professional">
                </div>
                <p class="card-text">University visits, career talks, sessions with doctors, engineers, researchers and IPT visits</p>
            </div>
        </div>
    </section>

</div>

@endsection