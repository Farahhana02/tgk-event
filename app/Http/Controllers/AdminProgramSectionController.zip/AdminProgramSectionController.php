<?php

namespace App\Http\Controllers;

use App\Models\Program;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class AdminProgramSectionController extends Controller
{
   
    /**
     * Update VIP Section
     */
    public function updateVip(Request $request, $id)
    {
        $program = Program::findOrFail($id);

        ini_set('upload_max_filesize', '20M');
        ini_set('post_max_size', '20M');
        ini_set('memory_limit', '256M');

        $vipList = [];
        
        if ($request->has('vip_list')) {
            foreach ($request->vip_list as $index => $vip) {
                $imagePath = null;
                
                // Handle new image upload
                if ($request->hasFile("vip_list.{$index}.image")) {
                    $image = $request->file("vip_list.{$index}.image");
                    $filename = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
                    $imagePath = $image->storeAs('vip_images', $filename, 'public');
                } elseif (isset($vip['existing_image'])) {
                    $imagePath = $vip['existing_image'];
                }

                $vipList[] = [
                    'name' => $vip['name'] ?? '',
                    'position' => $vip['position'] ?? '',
                    'image' => $imagePath,
                ];
            }
        }

        $program->update([
            'vip_list' => $vipList,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'VIP section updated successfully.',
        ]);
    }

    /**
     * Update Participation Section
     */
    public function updateParticipation(Request $request, $id)
    {
        $program = Program::findOrFail($id);

        ini_set('upload_max_filesize', '30M');
        ini_set('post_max_size', '30M');

        $request->validate([
            'participation_description' => 'nullable|string',
            'participation_prices' => 'nullable|array',
            'participation_form_type' => 'required|in:file,link',
            'participation_form_file' => 'nullable|file|mimes:pdf|max:30720',
            'participation_form_link' => 'nullable|url',
        ]);

        $formValue = $program->participation_form;

        if ($request->participation_form_type === 'file') {
            if ($request->hasFile('participation_form_file')) {
                // Delete old file
                if ($formValue && $program->participation_form_type === 'file') {
                    Storage::disk('public')->delete($formValue);
                }
                $formValue = $request->file('participation_form_file')->store('forms', 'public');
            }
        } else {
            $formValue = $request->participation_form_link;
        }

        $program->update([
            'participation_description' => $request->participation_description,
            'participation_prices' => $request->participation_prices,
            'participation_form_type' => $request->participation_form_type,
            'participation_form' => $formValue,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Participation section updated successfully.',
        ]);
    }

    /**
     * Update Sponsorship Section
     */
    public function updateSponsorship(Request $request, $id)
    {
        $program = Program::findOrFail($id);

        ini_set('upload_max_filesize', '30M');
        ini_set('post_max_size', '30M');

        $request->validate([
            'sponsorship_description' => 'nullable|string',
            'sponsorship_packages' => 'nullable|array',
            'sponsorship_additional_files' => 'nullable|file|mimes:pdf|max:30720',
            'sponsorship_form_type' => 'required|in:file,link',
            'sponsorship_form_file' => 'nullable|file|mimes:pdf|max:30720',
            'sponsorship_form_link' => 'nullable|url',
        ]);

        // Handle additional files
        $additionalFiles = $program->sponsorship_additional_files;
        if ($request->hasFile('sponsorship_additional_files')) {
            if ($additionalFiles) {
                Storage::disk('public')->delete($additionalFiles);
            }
            $additionalFiles = $request->file('sponsorship_additional_files')->store('sponsorship', 'public');
        }

        // Handle form
        $formValue = $program->sponsorship_form;
        if ($request->sponsorship_form_type === 'file') {
            if ($request->hasFile('sponsorship_form_file')) {
                if ($formValue && $program->sponsorship_form_type === 'file') {
                    Storage::disk('public')->delete($formValue);
                }
                $formValue = $request->file('sponsorship_form_file')->store('forms', 'public');
            }
        } else {
            $formValue = $request->sponsorship_form_link;
        }

        $program->update([
            'sponsorship_description' => $request->sponsorship_description,
            'sponsorship_packages' => $request->sponsorship_packages,
            'sponsorship_additional_files' => $additionalFiles,
            'sponsorship_form_type' => $request->sponsorship_form_type,
            'sponsorship_form' => $formValue,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Sponsorship section updated successfully.',
        ]);
    }

    /**
     * Update Programme Section (images + description)
     */
    public function updateProgramme(Request $request, $id)
    {
        $program = Program::findOrFail($id);

        ini_set('upload_max_filesize', '20M');
        ini_set('post_max_size', '20M');

        $request->validate([
            'programme_name' => 'nullable|string|max:255',
            'programme_description' => 'nullable|string',
            'programme_images' => 'nullable|array|max:4',
            'programme_images.*' => 'image|mimes:jpeg,png,jpg,gif,webp|max:15360',
        ]);

        $images = $program->programme_images ?? [];

        // Handle new image uploads
        if ($request->hasFile('programme_images')) {
            foreach ($request->file('programme_images') as $image) {
                if (count($images) < 4) {
                    $filename = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
                    $images[] = $image->storeAs('programme_images', $filename, 'public');
                }
            }
        }

        $program->update([
            'programme_name' => $request->programme_name,
            'programme_description' => $request->programme_description,
            'programme_images' => $images,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Programme section updated successfully.',
        ]);
    }

    /**
     * Delete a programme image
     */
    public function deleteProgrammeImage(Request $request, $id)
    {
        $program = Program::findOrFail($id);
        $imageIndex = $request->input('image_index');

        $images = $program->programme_images ?? [];
        
        if (isset($images[$imageIndex])) {
            Storage::disk('public')->delete($images[$imageIndex]);
            unset($images[$imageIndex]);
            $images = array_values($images); // Re-index array
        }

        $program->update(['programme_images' => $images]);

        return response()->json([
            'success' => true,
            'message' => 'Image deleted successfully.',
        ]);
    }
}