<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('participation_packages', function (Blueprint $table) {
            $table->id();

            $table->foreignId('programme_id')
                ->constrained('participation_programmes')
                ->cascadeOnDelete();

            $table->enum('package_type', ['one_person', 'multi_person']);
            $table->string('name');
            $table->decimal('price', 10, 2);

            // Only for multi-person packages
            $table->unsignedSmallInteger('people_per_package')->nullable();

            $table->text('description')->nullable();

            $table->unsignedSmallInteger('sort_order')->default(1);
            $table->boolean('is_active')->default(true);

            $table->timestamps();

            $table->index(['programme_id', 'package_type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('participation_packages');
    }
};
