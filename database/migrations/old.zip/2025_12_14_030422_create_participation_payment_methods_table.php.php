<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('participation_payment_methods', function (Blueprint $table) {
            $table->id();

            $table->foreignId('programme_id')
                ->constrained('participation_programmes')
                ->cascadeOnDelete();

            $table->string('bank');
            $table->string('account_number');
            $table->string('account_name');

            $table->boolean('is_active')->default(true);

            $table->timestamps();

            $table->index('programme_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('participation_payment_methods');
    }
};
